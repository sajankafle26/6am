import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Logo from "../assets/logo.png";
function News(props) {
    let [data, setData]=useState([''])
    useEffect(()=>{
        fetch(`https://newsapi.org/v2/top-headlines?category=${props.cat}&apiKey=69212c61a6aa4700b261a7d8925ca27b`).then((a)=>a.json()).then((b)=>setData(b.articles))
    },[])
  return (
    < >
     
      <section>
        <div className="container mx-auto">
            <div className="flex justify-between my-4 border-b pb-5">
                    <h4 className='font-bold text-2xl uppercase'>{props.cat}</h4>
                    <Link to="/" className=' bg-blue-700 text-lime-50 px-3 py-2'>Read More</Link>
            </div>

            <div className="flex gap-5 justify-between">
                {data.slice(0,3).map((a)=>(
 <div key={a} className='w-[32%]'>
 <img src={a.urlToImage ?  a.urlToImage : Logo} className='h-[220px] w-[100%]' alt="" />
 <h4 className='font-bold py-3 text-lg'> {a.title}</h4>
 <Link to={a.url} target='_blank'>Read More →</Link>
</div>
                ))}
               
            </div>
        </div>
      </section>
    </ >
  )
}

export default News
