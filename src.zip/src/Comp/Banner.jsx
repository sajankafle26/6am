import React, { useEffect, useState } from 'react'
import { useParams,Link } from 'react-router-dom'
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
function Banner() {
    let {cid}=useParams()
    let [data, setData]=useState([''])
    useEffect(()=>{
        fetch(`https://newsapi.org/v2/everything?q=bitcoin&apiKey=69212c61a6aa4700b261a7d8925ca27b`).then((a)=>a.json()).then((b)=>setData(b.articles))
    },[cid])
  return (
    < >
      <section className='border py-3'>
      <Swiper
      spaceBetween={50}
      slidesPerView={1}
      onSlideChange={() => console.log('slide change')}
      onSwiper={(swiper) => console.log(swiper)}
    >
        {data.slice(0,3).map((a)=>(
            <SwiperSlide key={a}>
                <img src={a.urlToImage} className='w-full h-[550px] object-cover' alt="" />
            </SwiperSlide>
        ))}
      
       
       
    </Swiper>
      </section>
    </ >
  )
}

export default Banner
