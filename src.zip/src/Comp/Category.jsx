import React, { useEffect, useState } from 'react'
import { useParams,Link } from 'react-router-dom'
import Logo from "../assets/logo.png";
function Category() {
    let {cid}=useParams()
    let [data, setData]=useState([''])
    useEffect(()=>{
        fetch(`https://newsapi.org/v2/top-headlines?category=${cid}&apiKey=69212c61a6aa4700b261a7d8925ca27b`).then((a)=>a.json()).then((b)=>setData(b.articles))
    },[cid])
  return (
    < >
      <section className='container mx-auto py-4'>
        <h2 className='text-2xl font-bold uppercase'>Category {cid}</h2>
        <div className="flex gap-5 justify-between flex-wrap">
                {data.map((a)=>(
 <div key={a} className='w-[32%]'>
 <img src={a.urlToImage ?  a.urlToImage : Logo} className='h-[220px] w-[100%]' alt="" />
 <h4 className='font-bold py-3 text-lg'> {a.title}</h4>
 <Link to={a.url} target='_blank'>Read More →</Link>
</div>
                ))}
               
            </div>
      </section>
    </ >
  )
}

export default Category
