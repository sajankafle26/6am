import React from 'react'
import { Link, Route, Routes } from 'react-router-dom'
import Home from '../Home'
import Category from './Category'

function Header() {
  return (
    < >
      <section className='py-3 border-b'>
            <div className="container mx-auto flex justify-between items-center">
                <div>
                    <Link to="/">
                    <img src="https://wowally.com/wp-content/themes/wowally/img/logo.png" alt="" />
                    </Link>
                </div>
                <nav>
                    <ul className='flex gap-6 font-semibold uppercase'>
                        <li><Link to="/cat/business">business</Link></li>
                        <li><Link to="/cat/entertainment">entertainment</Link></li>
                        <li><Link to="/cat/general">general</Link></li>
                        <li><Link to="/cat/health">health</Link></li>
                        <li><Link to="/cat/science">science</Link></li>
                    </ul>
                </nav>
                <div>
               <Link to="http://fb.com" ><i className="bi bi-facebook"></i></Link>
                <i className="bi bi-twitter ms-3"></i>
                </div>
            </div>
      </section>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/cat/:cid/" element={<Category/>} />
      </Routes>
    </ >
  )
}

export default Header
