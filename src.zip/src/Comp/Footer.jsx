import React from 'react'

function Footer() {
  return (
    < >
      <footer className=' bg-blue-800 py-7 text-center text-lime-50'>
        <p>     Home About Us Write for Us Contact Us Writing Shopping GAMING Travel </p>
        <img className='mx-auto py-8' src="https://wowally.com/wp-content/uploads/2022/12/logo.png" alt="" />
        <p>Use of this web site constitute acceptance of the Terms of Use andPrivacy Policy GDPR
          <br />
© wowally.com 2023 <br />
Article by wowally.com All right reserved. </p>
      </footer>
    </ >
  )
}

export default Footer
