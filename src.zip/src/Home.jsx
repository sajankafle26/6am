import React from 'react'
import News from './Comp/News'
import Banner from './Comp/Banner'

function Home() {
  return (
    < >
    <Banner/>
      <News cat="business"/>
      <News cat="entertainment"/>
      <News cat="general"/>
      <News cat="health"/>
      <News cat="science"/>
    </ >
  )
}

export default Home
